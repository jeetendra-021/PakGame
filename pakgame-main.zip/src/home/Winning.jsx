// import React, { useEffect, useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import Cookies from 'js-cookie';
// import './winner.css';

// const Winning = () => {
//   const baseURLAPI = import.meta.env.VITE_BASE_URL_API;
//   const navigate = useNavigate();
//   const [winners, setWinners] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [currentIndex, setCurrentIndex] = useState(0);

//   useEffect(() => {
//     const fetchWinners = async () => {
//       try {
//         const response = await fetch(baseURLAPI + 'users/WinnerList');
//         if (!response.ok) {
//           throw new Error('Network response was not ok');
//         }
//         const data = await response.json();
//         setWinners(data.data || []);
//       } catch (error) {
//         console.error('Error fetching winners:', error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchWinners();
//     const intervalId = setInterval(fetchWinners, 5000);

//     const interval = setInterval(() => {
//       setCurrentIndex((prevIndex) => (prevIndex + 5) % winners.length);
//     }, 3000);
//   // // fetchWinners();
//         // const intervalId = setInterval(fetchWinners, 5000); // Fetch every 5 seconds

//         // return () => clearInterval(intervalId); // Clear interval on component unmount
//     return () => clearInterval(intervalId); // Clear interval on unmount
//   }, [winners.length]);

//   if (loading) {
//     return <div>Loading...</div>;
//   }

//   // Display a maximum of 5 winners, rotating through the list
//   const currentWinners = winners.slice(currentIndex, currentIndex + 5).concat(
//     winners.slice(0, Math.max(0, currentIndex + 5 - winners.length))
//   );

//   return (
//     <>
//       <div className="row">
//         <div className="col-12">
//           <div className="lottery-heading">
//             <h3>Winning Information</h3>
//           </div>
//         </div>
        
//         {currentWinners.map((winner, index) => (
//           <div className="col-12" key={index}>
//             <div className={`winning-card ${index === 0 ? 'animated' : ''}`}>
//               <div className="winning-inner">
//                 <img
//                   src={`https://delristech-projects.in/pak_game/${winner.profile_image}`}
//                   alt="Winner Profile"
//                 />
//                 <h5>{winner.name}</h5>
//               </div>
//               <div className="winning-bottom">
//                 <div className="winning-image">
//                   <img src={winner.game_image} alt="Game" />
//                 </div>
//                 <div>
//                   <h3>Receive Rs {winner.amount}</h3>
//                   <h4>Winning Amount</h4>
//                 </div>
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>
//     </>
//   );
// };

// export default Winning;

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import './winner.css';

const Winning = () => {
  const baseURLAPI = import.meta.env.VITE_BASE_URL_API;
  const navigate = useNavigate();
  const [winners, setWinners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const fetchWinners = async () => {
      try {
        const response = await fetch(baseURLAPI + 'users/WinnerList');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setWinners(data.data || []);
        setCurrentIndex(0); // Reset index on new data fetch
      } catch (error) {
        console.error('Error fetching winners:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchWinners();
    
    const fetchInterval = setInterval(fetchWinners, 5000);
    const rotationInterval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 5) % winners.length);
    }, 3000);

    return () => {
      clearInterval(fetchInterval);
      clearInterval(rotationInterval);
    };
  }, [winners.length]);

  if (loading) {
    return <div>Loading...</div>;
  }

  const currentWinners = winners.slice(currentIndex, currentIndex + 5).concat(
    winners.slice(0, Math.max(0, currentIndex + 5 - winners.length))
  );

  return (
    <div className="row">
      <div className="col-12">
        <div className="lottery-heading">
          <h3>Winning Information</h3>
        </div>
      </div>
      
      {currentWinners.map((winner, index) => (
        <div className="col-12" key={index}>
          <div className={`winning-card ${index === 0 ? 'animated' : ''}`}>
            <div className="winning-inner">
              <img
                src={`https://delristech-projects.in/pak_game/${winner.profile_image}`}
                alt="Winner Profile"
              />
              <h5>{winner.name}</h5>
            </div>
            <div className="winning-bottom">
              <div className="winning-image">
                <img src={winner.game_image} alt="Game" />
              </div>
              <div>
                <h3>Receive Rs {winner.amount}</h3>
                <h4>Winning Amount</h4>
              </div> 
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Winning;

