import React, { useState, useEffect } from "react";

function WinnerNotification({ winners }) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (winners.length === 0) return;

    const interval = setInterval(() => {
      // Update index to show the next winner
      setCurrentIndex((prevIndex) => (prevIndex + 1) % winners.length);
    }, 3000); // Show each winner for 3 seconds

    return () => clearInterval(interval); // Clear interval on unmount
  }, [winners]);

  return (
    <div className="winner-container">
      {winners.length > 0 && {winner.map(winner  =>(
        <div className="col-12">
          <div className="winning-card">
            <div className="winning-inner">
              <img
                src={`https://delristech-projects.in/pak_game/${winner[currentIndex].profile_image}`}
                alt="Winner Profile"
              />
              <h5>{winner[currentIndex].name}</h5>
            </div>
            <div className="winning-bottom">
              <div className="winning-image">
                <img src={winner[currentIndex].game_image} alt="Game" />
              </div>
              <div>
                <h3>Receive Rs {winner[currentIndex].amount}</h3>
                <h4>Winning amount</h4>
              </div>
            </div>
          </div>
        </div>
      ))}
      }
    </div>
  );
}

export default WinnerNotification1;


