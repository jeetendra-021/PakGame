import React from 'react'

function FirstTry() {
  return (
    <div>
        <div className="container">
        <div className="row">
          <div className="col-lg-4 col-md-6 col-12 mx-auto bg-color">
<h1>Hello world</h1>
</div>
    </div>
    </div>
    </div>
  )
}

export default FirstTry
