import React, { useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import "./NotificationScreen.css";
import Cookies from 'js-cookie';

const notifications = [
  {
    title: "Dear members",
    content:
      "Dear members before withdrawing please confirm that your wallet has been verified, and the ID card and account number used for verification are true and valid, otherwise your withdrawal will not be successful!",
    timestamp: "2024-05-01 17:10:25",
  },
  {
    title: "Official Website",
    content:
      "To visit our official website, be sure to use the link below, https://www.pakgame.net! Please remember! Make sure not to provide personal data and personal transactions in any form and for any reason to other parties on behalf of PAKGames. Our side does not take private chats or calls to all members. Please inform all Referrals/other Members about this to avoid fraud. Thank you for your attention and cooperation!",
    timestamp: "2023-08-28 12:10:46",
  },
  {
    title: "Safe Recharge Tips",
    content:
      "All Recharge payment methods on the PAKGames site are only available in the Recharge menu on the official website. Do not trust other sources.",
    timestamp: "2023-05-05 11:15:25",
  },
];

const NotificationCard = ({ title, content, timestamp }) => (
  <div className="notification-card">
    <div className="notification-header">
      <span className="notification-icon">🔔</span>
      <h3 className="notification-title">{title}</h3>
    </div>
    <p className="notification-content">{content}</p>
    <p className="notification-timestamp">{timestamp}</p>
  </div>
);

const NotificationScreen = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const userId = Cookies.get('user_id');
    if (!userId) {
      navigate('/login');  
    }
  }, [navigate]);

  const handleBackClick = () => {
    navigate(-1);
  };

  return (
    <div className="col-lg-4 col-md-6 col-12 mx-auto agency-bg-color">
      <div className="title-header row mx-0">
        <div className="backPage col-2">
          <svg
            width={21}
            height={21}
            viewBox="0 0 21 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            onClick={handleBackClick}
            style={{ cursor: "pointer" }}
          >
            <path
              d="M13.6634 18.3412C13.8999 18.109 14.0345 17.7924 14.0377 17.461C14.0408 17.1295 13.9121 16.8104 13.68 16.5738L7.55115 10.3282L13.7967 4.19934C14.0266 3.96575 14.1556 3.6512 14.1558 3.32344C14.1561 2.99568 14.0276 2.68094 13.798 2.447C13.5685 2.21307 13.2562 2.07866 12.9285 2.07272C12.6008 2.06678 12.2839 2.18979 12.046 2.41526L4.90835 9.41951C4.67182 9.6517 4.53718 9.96833 4.53405 10.2998C4.53093 10.6312 4.65957 10.9503 4.89169 11.1869L11.8959 18.3245C12.1281 18.5611 12.4448 18.6957 12.7762 18.6988C13.1076 18.702 13.4268 18.5733 13.6634 18.3412Z"
              fill="black"
              style={{ fill: "#fff" }}
            />
          </svg>
        </div>
        <div className="col-8">
          <h4 className="text-center text-white">Notifications</h4>
        </div>
      </div>

      <div className="notification-container">
        {notifications.map((note, index) => (
          <NotificationCard
            key={index}
            title={note.title}
            content={note.content}
            timestamp={note.timestamp}
          />
        ))}
      </div>
    </div>
  );
};

export default NotificationScreen;
